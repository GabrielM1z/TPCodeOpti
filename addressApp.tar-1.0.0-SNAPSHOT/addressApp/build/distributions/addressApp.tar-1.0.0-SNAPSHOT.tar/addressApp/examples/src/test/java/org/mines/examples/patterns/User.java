package org.mines.examples.patterns;

record User(String firstname, String lastname, int age, double height) {


}

