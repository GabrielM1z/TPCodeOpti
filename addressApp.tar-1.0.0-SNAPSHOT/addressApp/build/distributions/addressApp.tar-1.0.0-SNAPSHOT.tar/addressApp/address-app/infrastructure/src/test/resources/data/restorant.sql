insert into restorant(uuid, name, rate, category) VALUES (uuid('fb74d086-5a4a-11e7-907b-a6006ad3dba0'), 'mcdo', 1, 'fastfood');
insert into restorant(uuid, name, rate, category) VALUES (uuid('fb74d086-5a4a-11e7-908b-a6006ad3dba7'), 'bk', 2, 'fastfood');
insert into restorant(uuid, name, rate, category) VALUES (uuid('fb74d084-5a4a-11e7-908b-a6056ad5dba7'), 'louis blanc', 5, 'gastronomique');

