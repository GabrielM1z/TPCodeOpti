truncate table targetaddress;
truncate table address;
truncate table town;
truncate table target;
truncate table restorant;
truncate table meal;
truncate table people;